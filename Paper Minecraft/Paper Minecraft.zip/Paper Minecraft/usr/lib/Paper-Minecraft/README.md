Created by Wallee#8314/Red-exe-Engineer with the Turbowarp packager (https://packager.turbowarp.org)

Code by Griffpatch (https://scratch.mit.edu/users/griffpatch)

Thanks to Nooz for the idea :p (https://github.com/mobilegmYT)

Loading screen background: https://www.artstation.com/artwork/q9wxrn

Favicon: Minecraft Pi texture atlas

This should work on any system with Chromium installed, if you want to use a different browser go to data/settings.json and edit it to use your prefered browser.

I am not sure if other browsers will work though

#!/usr/bin/python3
# Created by Wallee#8314/Red-exe-Engineer

from subprocess import run
from json import load

def browser(browser):
    system(f'{browser} --new-window --app=file:///usr/lib/Paper-Minecraft/index.html')

with open(f'/usr/lib/Paper-Minecraft/settings.json', "r") as file:
    data = load(file)

print(f'Using {data["browser"]} as browser')

run(f'{data["browser"]} --new-window --app=file:///usr/lib/Paper-Minecraft/index.html', shell=True, check=True)
